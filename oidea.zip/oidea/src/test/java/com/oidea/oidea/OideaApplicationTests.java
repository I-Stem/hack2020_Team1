package com.oidea.oidea;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OideaApplicationTests {

	@Test
	void contextLoads() {
	}

}
